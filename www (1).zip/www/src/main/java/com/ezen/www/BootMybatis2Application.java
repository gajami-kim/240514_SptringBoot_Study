package com.ezen.www;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMybatis2Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMybatis2Application.class, args);
	}

}
